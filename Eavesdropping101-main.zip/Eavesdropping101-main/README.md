# Eavesdropping101

Stamatics project covering basics of cryptography, covering :

- Linear Ciphers
- DES
- AES
- Number Theory and RSA
- Quantum Cryptography
- and much more...

## Mentored by:

- Abhinav Garg
- Devansh Jain
- Gargi Jain
