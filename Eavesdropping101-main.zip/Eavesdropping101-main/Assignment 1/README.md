# Meeting Larry Page

With efforts from some curious minds was born a blessing for curious minds named Google. You are given an opportunity to sit in a time machine and go back in time to meet Larry Page, one of the great minds behind Google. You sit in the time machine, enter the coordinates and time and are ready to go when the following pops up on the screen.
<br/>" Going to meet Larry Page, the founder of [google.com](google.com)? Must be <ins>**_feeling lucky_**</ins> no? Not that easy kid. Decipher the following and whisper the password to start this journey.
```
tbzvoclymifqef, kdr jriq ioklzbwbf, vzqgdgu iurqqivajp, fvsqpqket fwb wesmieqdnnab hfeotp qw rzroaggudk. afhd hhkcye, nlwi eqabpkyqhp rleejfv fs wclycrpvb, ceq kdrt laipsgivzv agkrdbfprgudk jriq abf pbg il vyve blovaf, iekj txdokfhe blovaf dc vivgbmj. pbgg hgp ga hrevfe pkf kuq exujjaga kj gtt_cwe_umh_lpcl_ntdwe.
```
Make sure that you are careful in every step and **_inspect every element_** of the problem. This **_class_** ain't an easy one."<br/>
Hints: [Cipher Used](https://www.geeksforgeeks.org/vigenere-cipher/), [Website to inspect](google.com), [Tool needed](https://developer.chrome.com/docs/devtools/overview/)<br/><br/>

- All pull requests (submissions) will be accepted only between 27th May 2023 00:00 to 28th May 2023 23:59
- Make a folder named as your roll no. inside this Assignment 1 directory
- In this folder (the one named <your_roll_no>), you are supposed to submit 2 files
  - python code to the solution (other programming languages are also acceptable)
  - README.md containing the solution and the final password
