# Magic is everywhere

Well... You cracked the code and the time machine is off to its destination... 4 September 1998, Menlo Park, California, United States, the foundation of Google... You start going back.... from 2023 to when noone had heard about corona to 2010s to 2000s to 1990s... wait... the machine doesnt stop... it keeps going back in time... you are out of luck.... the machine crashes in 1690s... in the land of witches... Thats right... Salem! 
<br></br>( [More on Salem Here](https://www.smithsonianmag.com/history/a-brief-history-of-the-salem-witch-trials-175162489/#:~:text=The%20Salem%20witch%20trials%20occurred,accused%20and%20compensated%20their%20families.). Note that this is not important for the assignment. Just for the sake of interest. )<br></br>

You crash in a cave. There is are scriptures on the wall. They read of a story, a story of an evil wizard in this land of wiches. His name was Jaffar. This cave was cursed to be a vantage point for all of time by him. He wanted all the "time energy" for himself, so he would trap the time travellers' souls and extract all the "time energy" from their machines and body. The last person that came into this cave was named Abhi. He came for the vengence for his father and succesfully fought Jaffar out of existence but had to pay with his soul being trapped in a hole inside the cave. The cave remained the vantage point for all of time travel. This soul has all the knowledge and resources you need to escape from this place. So now you need to free this soul to free yourself. You start looking for a hole and finally find one. You hear this voive coming out of it: <br></br>

https://github.com/quantum2409/Eavesdropping101/assets/98262532/6f8598c9-d769-4d45-b8ba-64e3cc9e3f7a

You, as an occasional piano player and a music lover identify the notes as D, E, B, A, C being played repititively. You ask the soul "how do I free you?" and a message appear beneath the hole.

```
qmnjvsa nv wewc flct vprj tj tvvplvl fv xja vqildhc xmlnvc nacyclpa fc gyt vfvw. fv wgqyp, pqq pqcs y wsq rx qmnjvafy cgv tlvhf cw tyl aeuq fv xja tkbv cqnsqs. lhf avawnc cv eas fuqb qvq tc yllrqr xxwa cfy. psdc uqf avrqc gefq pyat trac xwv taa wwd dv eas flcbq. vd trawm vupq quw x decgqcwt, yq yafl vlqs yqklhq! snafq vml lhvqpawr nqg_vfusr_ec_wawy qp fn wgawdgf.
```

The last words you hear are "whisper the password and i'll be free" and then... The walls of the cave start moving in... They are in to crush you... You need to free the soul before 7th June 2023 EOD or you will be crushed to death. ALL THE BEST.
