# DES encryption

This is a simple encryption assignment. Use the 8-bit ASCII representation of the word "VIcTorY" as the key to encrypt the word "CHAmpion" with 1-round DES. <br>
Submit the hex-Value of the encrypted text along with the code OR properly worked out solution in the form of pdf(or scanned copy).
