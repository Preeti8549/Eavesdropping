Final Answer:
Encryption
After initial permutation FF10C86D00F8EAC1
Round  1   00F8EAC1   953AB64D   A0B6826F6208
